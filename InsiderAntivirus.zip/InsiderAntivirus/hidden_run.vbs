Set objShell = CreateObject("WScript.Shell") 
objShell.Run """C:\Windows\pyw.exe"" ""C:\Users\Connor Ortiz\Desktop\InsiderAntivirus\scaner.py""", 1, False 
