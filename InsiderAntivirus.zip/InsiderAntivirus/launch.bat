@echo off
cd /d "%~dp0"
echo Set objShell = CreateObject("WScript.Shell") > hidden_run.vbs
echo objShell.Run """C:\Windows\pyw.exe"" ""%~dp0scaner.py""", 1, False >> hidden_run.vbs
wscript.exe hidden_run.vbs
