import os
import hashlib
import sys
import shutil
import tkinter as tk
from tkinter import ttk
from tkinter import filedialog
from tkinter import messagebox
import threading
import datetime
import urllib.request
import urllib.parse
import json
import time

# 🚨 REPLACE THIS WITH YOUR FREE KEY FROM VIRUSTOTAL.COM
VIRUSTOTAL_API_KEY = "19d100fadd52263bf5d6eb18637a326b15034f7a120c998174d93ea4607a2b89"

BAD_SIGNATURES = {
    "5d41402abc4b2a76b9719d911017c592": "Trojan.Generic.Win32",
    "098f6bcd4621d373cade4e832627b4f6": "Spyware.PasswordStealer",
    "202cb962ac59075b964b07152d234b70": "Ransomware.CryptoLock"
}

SKIP_FOLDERS = ["avg", "$recycle.bin"]
HIGH_RISK_EXTENSIONS = [".bat", ".vbs", ".scr", ".exe"]

QUARANTINE_DIR = r"E:\Python\Python Scripts\Python_Quarantine"
DESKTOP_PATH = os.path.join(os.path.expanduser("~"), "Desktop")
REPORTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Scan_Reports")

# GLOBAL FLAGS FOR CANCELLING SCANS
stop_scan_flag = False

RIGHT_CLICK_TARGET = None
if len(sys.argv) > 1:
    potential_path = " ".join(sys.argv[1:])
    if os.path.exists(potential_path):
        RIGHT_CLICK_TARGET = potential_path
def elevate_cpu_priority():
    try:
        import win32api
        import win32process
        pid = win32api.GetCurrentProcessId()
        handle = win32api.OpenProcess(win32process.PROCESS_ALL_ACCESS, True, pid)
        win32process.SetPriorityClass(handle, win32process.HIGH_PRIORITY_CLASS)
    except Exception:
        pass

def calculate_file_hash(file_path):
    hasher = hashlib.sha256() 
    try:
        if os.path.getsize(file_path) > 650000000:
            return None
        with open(file_path, 'rb') as file:
            buffer = file.read(65536)
            while len(buffer) > 0:
                hasher.update(buffer)
                buffer = file.read(65536)
        return hasher.hexdigest()
    except Exception:
        return None 

def check_file_content(file_path):
    try:
        if os.path.getsize(file_path) > 5000000: 
            return None
        with open(file_path, 'r', errors='ignore') as file:
            content = file.read(4096)
            if "X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*" in content:
                return "EICAR.Test.Virus.String"
    except Exception:
        return None
    return None

def check_virustotal(file_hash):
    if not VIRUSTOTAL_API_KEY or VIRUSTOTAL_API_KEY == "YOUR_VIRUSTOTAL_API_KEY_HERE":
        return None
    url = f"https://virustotal.com{file_hash}"
    req = urllib.request.Request(url)
    req.add_header("x-apikey", VIRUSTOTAL_API_KEY)
    try:
        with urllib.request.urlopen(req, timeout=3) as response:
            data = json.loads(response.read().decode())
            stats = data.get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
            malicious_count = stats.get("malicious", 0)
            if malicious_count >= 2:
                return f"Malware.Cloud (Flagged by {malicious_count} AV engines)"
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        if e.code == 429:
            return "API_LIMIT_HIT"
    except Exception:
        return None
    return None
def run_background_scan(target_folders):
    global files_scanned, stop_scan_flag
    files_scanned = 0
    threats_found = 0
    report_lines = []
    
    if isinstance(target_folders, str):
        target_folders = [target_folders]
        
    for target_dir in target_folders:
        if stop_scan_flag or not os.path.exists(target_dir):
            continue
            
        if os.path.isfile(target_dir):
            if stop_scan_flag: break
            full_path = target_dir
            file_name = os.path.basename(full_path)
            _, ext = os.path.splitext(file_name.lower())
            files_scanned += 1
            
            root.after(0, lambda f=file_name, c=files_scanned: status_label.config(text=f"Scanning file #{c}: {f}"))
            root.after(0, lambda: root.update_idletasks())
            
            threats_found += process_single_file(full_path, file_name, ext, report_lines)
            continue 
            
        for root_dir, dirs, files in os.walk(target_dir):
            if stop_scan_flag: break
            dirs[:] = [d for d in dirs if d.lower() not in SKIP_FOLDERS]
            
            for file_name in files:
                if stop_scan_flag: break
                full_path = os.path.join(root_dir, file_name)
                _, ext = os.path.splitext(file_name.lower())
                files_scanned += 1
                
                root.after(0, lambda f=file_name, c=files_scanned: status_label.config(text=f"Scanning file #{c}: {f}"))
                root.after(0, lambda: root.update_idletasks())
                
                threats_found += process_single_file(full_path, file_name, ext, report_lines)
                
    # Finish actions based on whether it completed or was aborted
    if stop_scan_flag:
        root.after(0, lambda: status_label.config(text="⛔ Scan Aborted by User Manually.", fg="orange"))
    else:
        if threats_found > 0:
            root.after(0, lambda: status_label.config(text=f"Scan Complete: Found {threats_found} threat/risk items!", fg="red"))
        else:
            root.after(0, lambda: status_label.config(text=f"Scan Complete: Checked {files_scanned} target files safely.", fg="green"))
    
    save_scan_report(files_scanned, threats_found, report_lines)
    root.after(0, lambda: toggle_buttons(tk.NORMAL))

def process_single_file(full_path, file_name, ext, report_lines):
    internal_threat = check_file_content(full_path)
    if internal_threat:
        report_lines.append(f"⚠️ CONTENT MATCH | Name: {file_name} | Threat: {internal_threat} | Path: {full_path}")
        root.after(0, lambda f=file_name, p=full_path, t=internal_threat: results_tree.insert(
            "", "end", values=(f, "⚠️ MALWARE MATCH", t, p), tags=('threat',)))
        return 1
    
    file_hash = calculate_file_hash(full_path)
    
    if ext in HIGH_RISK_EXTENSIONS or ext in [".dll", ".msi", ".cmd"]:
        cloud_result = check_virustotal(file_hash)
        if cloud_result == "API_LIMIT_HIT":
            root.after(0, lambda: status_label.config(text="⏳ Cloud API limit reached. Pacing scan engine...", fg="orange"))
            time.sleep(15) 
            cloud_result = check_virustotal(file_hash)
            
        if cloud_result and cloud_result != "API_LIMIT_HIT":
            report_lines.append(f"⚠️ CLOUD MALWARE MATCH | Name: {file_name} | Threat: {cloud_result} | Path: {full_path}")
            root.after(0, lambda f=file_name, p=full_path, t=cloud_result: results_tree.insert(
                "", "end", values=(f, "⚠️ MALWARE MATCH", t, p), tags=('threat',)))
            return 1
    
    if file_hash in BAD_SIGNATURES:
        threat_name = BAD_SIGNATURES[file_hash]
        report_lines.append(f"⚠️ LOCAL MALWARE MATCH | Name: {file_name} | Threat: {threat_name} | Path: {full_path}")
        root.after(0, lambda f=file_name, p=full_path, t=threat_name: results_tree.insert(
            "", "end", values=(f, "⚠️ MALWARE MATCH", t, p), tags=('threat',)))
        return 1
    
    if ext in HIGH_RISK_EXTENSIONS:
        heuristic_reason = None
        try:
            if os.path.getsize(full_path) == 0:
                heuristic_reason = "Suspicious Empty Executable/Script"
            elif ext in [".bat", ".vbs", ".scr"] and ("downloads" in full_path.lower() or "desktop" in full_path.lower()):
                heuristic_reason = "Unsigned Script in User Directory"
        except Exception:
            pass
        
        if heuristic_reason:
            report_lines.append(f"🚨 HIGH RISK EXTENSION | Name: {file_name} | Reason: {heuristic_reason} | Path: {full_path}")
            root.after(0, lambda f=file_name, p=full_path, h=heuristic_reason: results_tree.insert(
                "", "end", values=(f, "🚨 HIGH RISK EXTENSION", h, p), tags=('high_risk',)))
            return 1
            
    if files_scanned % 50 == 0 or files_scanned < 15:
        root.after(0, lambda f=file_name, p=full_path: results_tree.insert(
            "", "end", values=(f, "Clean", "None", p)))
            
    return 0
def toggle_buttons(state):
    scan_btn.config(state=state)
    quick_scan_btn.config(state=state)

def trigger_stop_scan():
    global stop_scan_flag
    stop_scan_flag = True
    status_label.config(text="Stopping scan engines safely...", fg="orange")

def start_custom_scan():
    target_dir = path_entry.get()
    if not target_dir or not os.path.exists(target_dir):
        messagebox.showwarning("Select Folder", "Please select a valid folder to scan first.")
        return
    clear_tree_and_start(target_dir)

def start_quick_scan():
    user_profile = os.path.expanduser("~")
    quick_targets = [
        os.path.join(user_profile, "Desktop"),
        os.path.join(user_profile, "Downloads"),
        os.path.join(user_profile, "Documents"),
        os.path.join(user_profile, "AppData", "Local", "Temp")
    ]
    path_entry.delete(0, tk.END)
    path_entry.insert(0, "⚡ Whole Computer Quick Scan Active")
    clear_tree_and_start(quick_targets)

def clear_tree_and_start(targets):
    global stop_scan_flag
    stop_scan_flag = False # Reset flag on launch
    for row in results_tree.get_children():
        results_tree.delete(row)
    status_label.config(text="Initializing security engines...", fg="blue")
    toggle_buttons(tk.DISABLED)
    
    if isinstance(targets, str):
        targets = [targets]
        
    scan_thread = threading.Thread(target=run_background_scan, args=(targets,), daemon=True)
    scan_thread.start()
def view_quarantine_storage():
    for row in results_tree.get_children():
        results_tree.delete(row)
        
    if not os.path.exists(QUARANTINE_DIR) or len(os.listdir(QUARANTINE_DIR)) == 0:
        messagebox.showinfo("Quarantine Empty", "No existing files found in your E: drive Quarantine storage.")
        status_label.config(text="Quarantine vault is empty.", fg="gray")
        return
        
    path_entry.delete(0, tk.END)
    path_entry.insert(0, "🔒 Viewing E: Drive Quarantine Storage")
    
    files_found = 0
    for item in os.listdir(QUARANTINE_DIR):
        if item.startswith("QUARANTINED_") and item.endswith(".locked"):
            files_found += 1
            # Embedded routing tag splitter to reconstruct old storage links
            parts = item.replace("QUARANTINED_", "").replace(".locked", "").split("_FROM_")
            display_name = parts[0]
            orig_encoded = parts[1].replace("_", "\\") if len(parts) > 1 else "UNKNOWN"
            
            results_tree.insert("", "end", values=(display_name, "🔒 QUARANTINED", f"Isolated from {orig_encoded}", orig_encoded), tags=('quarantined',))
            
    status_label.config(text=f"Loaded {files_found} historical threat(s) from your E: drive storage vault.", fg="blue")

def quarantine_selected_file():
    selected_item = results_tree.selection()
    if not selected_item:
        messagebox.showwarning("No Selection", "Please click on a detected Threat or High Risk file in the table first.")
        return
        
    item_values = results_tree.item(selected_item, "values")
    file_name = item_values[0]
    security_status = item_values[1]
    original_path = item_values[3]
    
    if security_status == "Clean" or security_status == "🔒 QUARANTINED":
        messagebox.showinfo("Action Skipped", "This file is already quarantined or safe.")
        return
        
    if not os.path.exists(QUARANTINE_DIR):
        try: os.makedirs(QUARANTINE_DIR)
        except Exception as dir_err:
            messagebox.showerror("Folder Error", f"Could not create directory on E: drive:\n\n{dir_err}")
            return
    
    # Encodes path maps directly into the title string so the file can find its way home later
    safe_path_string = original_path.replace("\\", "_").replace(":", "")
    destination_path = os.path.join(QUARANTINE_DIR, f"QUARANTINED_{file_name}_FROM_{safe_path_string}.locked")
    
    try:
        shutil.move(original_path, destination_path)
        results_tree.item(selected_item, values=(file_name, "🔒 QUARANTINED", f"Isolated in {QUARANTINE_DIR}", original_path), tags=('quarantined',))
        messagebox.showinfo("Success", f"Successfully quarantined {file_name} to E: drive!")
    except Exception as error:
        messagebox.showerror("Quarantine Failed", f"Could not move file:\n\n{error}")

def release_selected_file():
    """Extracts files from the vault and moves them back to their original home locations."""
    selected_item = results_tree.selection()
    if not selected_item:
        messagebox.showwarning("No Selection", "Please go to 'View Vault' and select a quarantined item first.")
        return
        
    item_values = results_tree.item(selected_item, "values")
    file_name = item_values[0]
    security_status = item_values[1]
    original_home_path = item_values[3]
    
    if security_status != "🔒 QUARANTINED":
        messagebox.showwarning("Action Invalid", "You can only restore items currently stored in the Vault.")
        return
        
    # Re-verify the vault database file exists
    vault_tag = original_home_path.replace("\\", "_").replace(":", "")
    vault_file_name = f"QUARANTINED_{file_name}_FROM_{vault_tag}.locked"
    vault_full_path = os.path.join(QUARANTINE_DIR, vault_file_name)
    
    if not os.path.exists(vault_full_path):
        messagebox.showerror("Missing Asset", "Could not locate vault signature file on your E: drive.")
        return
        
    # Ensure destination home tree directories exist
    home_directory = os.path.dirname(original_home_path)
    if not os.path.exists(home_directory):
        os.makedirs(home_directory)
        
    try:
        shutil.move(vault_full_path, original_home_path)
        results_tree.delete(selected_item) # Wipe entry from current vault view layout
        messagebox.showinfo("Restored", f"Successfully released '{file_name}' back to:\n{original_home_path}")
    except Exception as err:
        messagebox.showerror("Release Aborted", f"Could not recover item from containment:\n\n{err}")

def save_scan_report(total_scanned, threats_found, details):
    if not os.path.exists(REPORTS_DIR):
        os.makedirs(REPORTS_DIR)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    report_filename = os.path.join(REPORTS_DIR, f"Scan_Report_{timestamp}.txt")
    try:
        with open(report_filename, "w", encoding="utf-8") as report_file:
            report_file.write(f"SCAN REPORT - {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            report_file.write(f"Total Files Scanned: {total_scanned}\n")
            report_file.write(f"Threats Detected: {threats_found}\n")
            report_file.write("-" * 50 + "\n\n")
            if details:
                for line in details: report_file.write(line + "\n")
            else:
                report_file.write("No threats detected during this scan.\n")
    except Exception: pass
def select_folder():
    folder = filedialog.askdirectory()
    if folder:
        path_entry.delete(0, tk.END)
        path_entry.insert(0, folder)

root = tk.Tk()
root.title("Insider Antivirus")
root.geometry("850x520")
root.configure(bg="#f5f6f8")

# Input Frame
input_frame = tk.Frame(root, bg="#f5f6f8")
input_frame.pack(pady=10, fill="x", padx=10)

path_entry = tk.Entry(input_frame, width=65, font=("Arial", 10))
path_entry.pack(side="left", padx=5, ipady=3)

browse_btn = tk.Button(input_frame, text="Browse Folder", command=select_folder, 
                       bg="#4a5568", fg="white", activebackground="#2d3748", activeforeground="white",
                       relief="flat", padx=10)
browse_btn.pack(side="left")

# Controls Frame
btn_frame = tk.Frame(root, bg="#f5f6f8")
btn_frame.pack(pady=10)

# Main Controls Layout Panel
scan_btn = tk.Button(btn_frame, text="🔍 Custom Scan", command=start_custom_scan, font=("Arial", 9, "bold"),
                     bg="#1e40af", fg="white", activebackground="#1e3a8a", activeforeground="white",
                     relief="groove", padx=10, pady=4)
scan_btn.pack(side="left", padx=4)

quick_scan_btn = tk.Button(btn_frame, text="⚡ Quick Scan", command=start_quick_scan, font=("Arial", 9, "bold"),
                           bg="#d97706", fg="white", activebackground="#b45309", activeforeground="white",
                           relief="groove", padx=10, pady=4)
quick_scan_btn.pack(side="left", padx=4)

# ⛔ NEW STOP BUTTON: Styled in striking deep charcoal-burgundy
stop_btn = tk.Button(btn_frame, text="⛔ Stop Scan", command=trigger_stop_scan, font=("Arial", 9, "bold"),
                     bg="#374151", fg="white", activebackground="#1f2937", activeforeground="white",
                     relief="groove", padx=10, pady=4)
stop_btn.pack(side="left", padx=4)

quarantine_btn = tk.Button(btn_frame, text="🛡️ Quarantine", command=quarantine_selected_file, font=("Arial", 9, "bold"),
                           bg="#dc2626", fg="white", activebackground="#991b1b", activeforeground="white",
                           relief="groove", padx=10, pady=4)
quarantine_btn.pack(side="left", padx=4)

view_q_btn = tk.Button(btn_frame, text="🔒 View Vault", command=view_quarantine_storage, font=("Arial", 9, "bold"),
                       bg="#059669", fg="white", activebackground="#065f46", activeforeground="white",
                       relief="groove", padx=10, pady=4)
view_q_btn.pack(side="left", padx=4)

# ↩️ NEW RELEASE BUTTON: Styled in a soft light teal-blue tint for restorations
release_btn = tk.Button(btn_frame, text="↩️ Release File", command=release_selected_file, font=("Arial", 9, "bold"),
                        bg="#0ea5e9", fg="white", activebackground="#0369a1", activeforeground="white",
                        relief="groove", padx=10, pady=4)
release_btn.pack(side="left", padx=4)

# Status Label
status_label = tk.Label(root, text="System Ready", fg="#16a34a", bg="#f5f6f8", font=("Arial", 11, "bold"))
status_label.pack(pady=5)

# Results Tree View
columns = ("Name", "Status", "Details", "Path")
results_tree = ttk.Treeview(root, columns=columns, show="headings")
for col in columns:
    results_tree.heading(col, text=col)
results_tree.pack(fill="both", expand=True, padx=10, pady=10)

results_tree.tag_configure('threat', background='#ffcccc')
results_tree.tag_configure('high_risk', background='#ffe6cc')
results_tree.tag_configure('quarantined', background='#d1e7dd')

elevate_cpu_priority()

if RIGHT_CLICK_TARGET:
    path_entry.delete(0, tk.END)
    path_entry.insert(0, RIGHT_CLICK_TARGET)
    root.after(100, lambda: clear_tree_and_start([RIGHT_CLICK_TARGET]))

root.mainloop()
